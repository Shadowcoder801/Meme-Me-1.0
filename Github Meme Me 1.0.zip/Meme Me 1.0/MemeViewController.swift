
//  ViewController.swift
//  Meme2
//
//  Created by Kyle Humphrey on 7/19/17.
//  Copyright © 2017 Humphrey Corporations. All rights reserved.
//


import UIKit

class MemeViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate
{
    /*
 
        COMMENTS:
     
            This project was a lot of hard work.  In hindsight I see that maybe if I set the text field contraints to 
        fit into the Imager Picker View instead of the Meme View, it would have been easier.  Since it is not part of 
        the grading rubric, I will test those changes in Meme Me 2.0.
     
            I believe I have done everything well and good according to the rubric, but I have no idea what the 
        save method does, except that it's a stub and the Meme Object created will be used for later.
     
            If I have any required changes, please elaborate on whether the problem can be fixed in Storyboard, the
        View Controller.swift file, or if it can be fixed from the XCode Toolbar above.  Thank you!
     
    */
    
    // Text Field Outlets
    
    @IBOutlet weak var topTextField: UITextField!
    @IBOutlet weak var bottomTextField: UITextField!
    
    // The Meme View's Height
    
    @IBOutlet weak var memeViewHeightConstraint: NSLayoutConstraint!
    
    // Image Picker View Outlet
    
    @IBOutlet weak var imagePickerView: UIImageView!
    
    // Constraints for the Image Picker View's Bounds (Left, Right, Up, and Down)
    // Used to stretch and shrink the Image Picker
    
    @IBOutlet weak var imagePickerLeadingConstraint: NSLayoutConstraint!
    @IBOutlet weak var imagePickerTrailingConstraint: NSLayoutConstraint!
    @IBOutlet weak var imagePickerTopConstraint: NSLayoutConstraint!
    @IBOutlet weak var imagePickerBottomConstraint: NSLayoutConstraint!
    
    // Constraints for vertical positioning of the text fields
    // Increasing the either of them will bring the text field closer to the center
    
    @IBOutlet weak var topTextFieldConstraintY: NSLayoutConstraint!
    @IBOutlet weak var bottomTextFieldConstraintY: NSLayoutConstraint!
    
    
    // Toolbar Outlets
    
    @IBOutlet weak var photoActionsToolbar: UIToolbar!
    @IBOutlet weak var memeActionsToolbar: UIToolbar!
    
    // Bar Button Item Outlets
    
    @IBOutlet weak var shareButton: UIBarButtonItem!
    @IBOutlet weak var cancelButton: UIBarButtonItem!
    @IBOutlet weak var cameraButton: UIBarButtonItem!
    @IBOutlet weak var albumButton: UIBarButtonItem!
    
    // Variables for the longer and shorter screen lengths
    // Used to determine the length of the screen if it is portrait or landscape
    
    var portraitLength: CGFloat!
    var landscapeLength: CGFloat!
    
    // If the Top Text Field is Touched (default: true)
    
    var topTextFieldTouched = true
    
    // If the Image is not too thin or short
    
    var hasProperRange = true
    
    // If the screen is portrait or landscape
    // Technically only one is needed, but I put both in for easier code reading
    
    var isPortrait: Bool!
    var isLandscape: Bool!
    
    // The value of how high the screen will rise with the keyboard
    
    var keyboardShift: CGFloat!
    
    // An Image Picker Contoller
    
    let imagePicker = UIImagePickerController()
    
    // Default Values of Constraint Constants
    
    let defaultTextFieldConstantY = CGFloat(60)
    let totalHeightOfToolbars = CGFloat(100)
    let minWidth = CGFloat(70)
    let minHeight = CGFloat(120)
    
    // A Meme Model
    
    var newMeme: Meme!
    
    struct Meme
    {
        var topText: String!
        var bottomText: String!
        var originalImage: UIImage!
        var memeImage: UIImage!
    }
    
    
    // MARK: View Will Appear Functions
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        
        imagePickerIsAspectFit(isAspectFit: false)
        
        determinePortraitAndLandscapeLengths()
        
        determineOrientation()
        
        checkIfCameraIsAvailable()
        
        initializeTextFields()
        
        subscribeToKeyboardNotifications()
    }
    
    func imagePickerIsAspectFit(isAspectFit: Bool)
    {
        // Under normal circumstances Image Picker View is always Aspect Fit
        
        // But the Aspect Ratio is too thin or short, the Image Picker View needs to stretch to fit the minimum size the Image Picker View can handle (see checkForProperImageRange function)
        
        if isAspectFit
        {
            imagePickerView.contentMode = UIViewContentMode.scaleAspectFit
        }
        else
        {
            imagePickerView.contentMode = UIViewContentMode.scaleToFill
        }
    }
    
    func determinePortraitAndLandscapeLengths()
    {
        // Records the length of the longer side of the iDevice (Portrait Length) and the shorter side (Landscape Length)
        
        // Meme Me 1.0 uses these as references since sometimes the frame size's widths and heights don't change when the devices orientation changes.
        
        portraitLength = getMax(num1: self.view.frame.size.width, num2: self.view.frame.size.height)
        landscapeLength = getMin(num1: self.view.frame.size.width, num2: self.view.frame.size.height)
    }
    
    func getMax(num1: CGFloat, num2: CGFloat) -> CGFloat
    {
        // Takes two numbers and returns the higher value (Order matters if numbers have a chance of being equal)
        
        return (num1 >= num2) ? num1 : num2
    }
    
    func getMin(num1: CGFloat, num2: CGFloat) -> CGFloat
    {
        // Takes two numbers and returns the lower value (Order matters if numbers have a chance of being equal)
        
        return (num1 <= num2) ? num1 : num2
    }
    
    func determineOrientation()
    {
        // Records whether the Device is portrait or landscape into two booleans
        
        // Technically isLandscape can be replaced with !isPortrait but I find the code to be easier to read this way
        
        isPortrait = UIDevice.current.orientation.isPortrait
        isLandscape = !isPortrait
    }
    
    func checkIfCameraIsAvailable()
    {
        if !UIImagePickerController.isSourceTypeAvailable(.camera)
        {
            cameraButton.isEnabled = false
        }
        
    }
    
    func initializeTextFields()
    {
        setMemeAttributes()
        
        setMemeAlignment()
        
        setMemeDelegates()
    }
    
    func setMemeAttributes()
    {
        // Initializes the fields with the attributes of how many Meme texts look like
        
        let memeTextAttributes : [String: Any] =
        [
            NSStrokeColorAttributeName: UIColor.black,
            NSForegroundColorAttributeName: UIColor.white,
            NSFontAttributeName: UIFont(name: "HelveticaNeue-CondensedBlack", size: 40)!,
            NSStrokeWidthAttributeName: Float(-5)
        ]
        
        topTextField.defaultTextAttributes = memeTextAttributes
        bottomTextField.defaultTextAttributes = memeTextAttributes
    }
    
    func setMemeAlignment()
    {
        // Centers the text
        
        topTextField.textAlignment = NSTextAlignment.center
        bottomTextField.textAlignment = NSTextAlignment.center
    }
    
    func setMemeDelegates()
    {
        // The delegate for the text fields is this view controller (MemeViewController)
        
        topTextField.delegate = self
        bottomTextField.delegate = self
    }
    
    // MARK: Keyboard Functions
    
    func subscribeToKeyboardNotifications()
    {
        // Adds the two observers KeyboardWillShow and Keyboard will hide
        
        // Honestly, I do not know the ups and downs of observors but I believe that they act as functions triggered by an event occuring in the Device
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: .UIKeyboardWillShow, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: .UIKeyboardWillHide, object: nil)
    }
    
    func unsubscribeFromKeyboardNotifications()
    {
        // Removes the two observers from the Notifications Center
        
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
    }
    
    
    func keyboardWillShow(_ notification:Notification)
    {
        // Determines whether the screen needs to be shifted up and shifts the screen up if necessary
        
        let actualShift: CGFloat!
        
        getKeyboardShift(notification)
        
        actualShift = determineActualShift()
        
        view.frame.origin.y = actualShift
    }
    
    func getKeyboardShift(_ notification:Notification)
    {
        // Gets the numeric value for the shift in the screen's y-position which can vary depending on if the Device is Portrait or Landscape
        
        // I put this in a variable because it is not guaranteed whether the keyboard will need to shift, depending on which text field is touched
        
        keyboardShift = -getKeyboardHeight(notification)
    }
    
    func determineActualShift() -> CGFloat
    {
        // Determines whether the screen needs to shift depending on what text field gets touched
        
        // The screen will only shift if the bottom text field is touched
        
        let actualShift: CGFloat!
        
        if topTextFieldTouched
        {
            actualShift = 0
        }
        else
        {
            actualShift = keyboardShift
            
            bottomTextFieldStaysOnScreen()
        }
        
        return actualShift
    }
    
    func bottomTextFieldStaysOnScreen()
    {
        // Resets the constraints for the Image Picker View and the Bottom Text Field to help ensure the Bottom Text Field will stay on the screen after the shift
        
        if isPortrait && (portraitLength - keyboardShift - imagePickerBottomConstraint.constant - defaultTextFieldConstantY < 0)
        || isLandscape && (landscapeLength - keyboardShift - imagePickerBottomConstraint.constant - defaultTextFieldConstantY < 0)
        {
            imagePickerBottomConstraint.constant = 0
            
            bottomTextFieldConstraintY.constant = defaultTextFieldConstantY
        }
    }
    
    func getKeyboardHeight(_ notification:Notification) -> CGFloat
    {
        let userInfo = notification.userInfo
        let keyboardSize = userInfo![UIKeyboardFrameEndUserInfoKey] as! NSValue // of CGRect
        return keyboardSize.cgRectValue.height
    }
    
    func keyboardWillHide(_ notification:Notification)
    {
        // Resets the screen and constraints back to their original positions before the shift
        
        view.frame.origin.y = 0
        
        bottomTextFieldGetsAdjustedBack()
    }
    
    func bottomTextFieldGetsAdjustedBack()
    {
        // Resets the constraints to their original positions before the shift
        
        // Image Picker Bottom Constraint is always the same as Image Picker Top Constraint except for when the shift occurs, so it can get its old value from the Top Constraint
        
        // The same is true for the bottom text field y constraint
        
        imagePickerBottomConstraint.constant = imagePickerTopConstraint.constant
        bottomTextFieldConstraintY.constant = topTextFieldConstraintY.constant
    }
    
    // MARK: Camera and Album Button Functions
    
    @IBAction func cameraButonPressed()
    {
        // Presents an Image Picker View based with the camera as the source
        
        imagePicker.sourceType = .camera
        imagePicker.delegate = self
            
        self.present(imagePicker, animated: true, completion: nil)
        
    }
    
    @IBAction func albumButonPressed()
    {
        // Presents an Image Picker Controller with the Album as its source
        
        imagePicker.sourceType = .photoLibrary
        imagePicker.delegate = self
        
        self.present(imagePicker, animated: true, completion: nil)
    }
    
    
    // MARK: Image Picker Delegate Functions
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any])
    {
        // Determines if the Image Picker View can successfully get an image from the Image Picker Controller
        
        // If yes, the Image Picker View's dimensions get adjusted to fit the image
        
        // If no, an alert is presented
        
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage
        {
            adjustToProportionalImageSize(image: image)
            
            imagePickerView.image = image
            
            checkForProperImageRange(presentingVC: picker, presentAlert: true)
            
            checkDismissal(picker: picker)
        }
        else
        {
            presentOKAlert(title: "Image Casting Error", message: "Sorry, but Meme Me 1.0 could not properly format the image.")
        }
    }
    
    func adjustToProportionalImageSize(image: UIImage)
    {
        // Adjusts the Image Picker View to the same aspect ratio as the image
        
        // Adjusting the Content Mode to Aspect Fit alone produced some width and height erros when I switched orientation
        
        resetPreviousAdjustments()
        
        determineOrientation()
        
        let tallerImage = isImageTallerThanFrame(image: image)
        
        if tallerImage
        {
            adjustImagePickerWidth(image: image)
        }
        else
        {
            adjustImagePickerHeight(image: image)
        }
    }
    
    func resetPreviousAdjustments()
    {
        // Resets Image Picker Constraints, Text Field Constraints, and Image Picker Frame Dimensions to their default values
        
        imagePickerLeadingConstraint.constant = 0
        imagePickerTrailingConstraint.constant = 0
        imagePickerBottomConstraint.constant = 0
        imagePickerTopConstraint.constant = 0
        
        topTextFieldConstraintY.constant = defaultTextFieldConstantY
        bottomTextFieldConstraintY.constant = defaultTextFieldConstantY
        
        determineOrientation()
        
        imagePickerView.frame.size.width = getImagePickerWidth()
        imagePickerView.frame.size.height = getImagePickerHeight()
    }
    
    func isImageTallerThanFrame(image: UIImage) -> Bool
    {
        // Returns if true if the Image's (height/width) is greater than or equal to the Image Picker's default (height/width)
        
        let frameSlope = determineFrameSlope()
        let imageSlope = image.size.height / image.size.width
        
        return imageSlope >= frameSlope
    }
    
    func determineFrameSlope() -> CGFloat
    {
        // Determines what the Image Picker's (height/width) should be based on the device's orientation
        
        let frameSlope: CGFloat!
        
        if isPortrait
        {
            frameSlope = (portraitLength - totalHeightOfToolbars) / landscapeLength
        }
        else
        {
            frameSlope =  (landscapeLength - totalHeightOfToolbars) / portraitLength
        }
        
        return frameSlope
    }
    
    func adjustImagePickerHeight(image: UIImage)
    {
        // Adjusts the Image Picker's Height to match the aspect ratio of the Image
        
        let oldImagePickerWidth = getImagePickerWidth()
        
        let oldImagePickerHeight = getImagePickerHeight()
        
        imagePickerView.frame.size.height = oldImagePickerWidth * (image.size.height / image.size.width)
        
        let heightDifference = (oldImagePickerHeight - imagePickerView.frame.size.height)
        
        imagePickerBottomConstraint.constant += heightDifference / 2
        
        imagePickerTopConstraint.constant += heightDifference / 2
        
        topTextFieldConstraintY.constant += heightDifference / 2
        
        bottomTextFieldConstraintY.constant += heightDifference / 2
        
        debug(message: "Adjusted the Height")
    }
    
    func adjustImagePickerWidth(image: UIImage)
    {
        // Adjusts the Image Picker's Width to match the aspect ratio of the Image
        
        let oldImagePickerWidth = getImagePickerWidth();
        
        let oldImagePickerHeight = getImagePickerHeight();
        
        let newImagePickerWidth = oldImagePickerHeight * (image.size.width / image.size.height);
        
        let widthDifference = oldImagePickerWidth - newImagePickerWidth
        
        imagePickerView.frame.size.width = newImagePickerWidth
        
        imagePickerLeadingConstraint.constant += widthDifference / 2;
        
        imagePickerTrailingConstraint.constant += widthDifference / 2;
        
        debug(message: "Adjusted the Width")
    }
    
    func getImagePickerWidth() -> CGFloat
    {
        // Gets the Image Picker's Width based on whether the device is portrait or landscape
        
        let width: CGFloat!
        
        if isPortrait
        {
            width = landscapeLength
        }
        else
        {
            width = portraitLength
        }
        
        return width
    }
    
    func getImagePickerHeight() -> CGFloat
    {
        // Gets the Image Picker's Height based on whether the device is portrait or landscape
        
        let height: CGFloat!
        
        if isPortrait
        {
            height = portraitLength - totalHeightOfToolbars
        }
        else
        {
            height = landscapeLength - totalHeightOfToolbars
        }
        
        return height
    }
    
    func checkForProperImageRange(presentingVC: UIViewController, presentAlert: Bool)
    {
        // Checks to see if the Image is too thin or short
        
        // If the Image is too thin or short, it will adjust the Image Picker to its thinnest or shortest size respectively and present an alert
        
        if !hasProperWidth() || !hasProperHeight()
        {
            hasProperRange = false
            
            imagePickerIsAspectFit(isAspectFit: false)
            
            adjustToMinimumImageRange()
            
            checkOutOfRangeVC(presentingVC: presentingVC, presentAlert: presentAlert)
        }
        else
        {
            hasProperRange = true
        }
    }
    
    func adjustToMinimumImageRange()
    {
        // Adjusts the Image Picker's size and constraints to its shortest/thinnest size which is also dependent on whether the device is portrait or landscape
        
        if !hasProperWidth() && isPortrait
        {
            readjustWidthConstraints(screenWidth: landscapeLength)
            
            imagePickerView.frame.size.width = minWidth
        }
        else if !hasProperWidth() && isLandscape
        {
            readjustWidthConstraints(screenWidth: portraitLength)
            
            imagePickerView.frame.size.width = minWidth
        }
        else if !hasProperHeight() && isPortrait
        {
            readjustHeightConstraints(screenHeight: portraitLength)
            
            readjustTextFieldConstraints(newHeight: minHeight)
            
            imagePickerView.frame.size.height = minHeight
        }
        else if !hasProperHeight() && isLandscape
        {
            readjustHeightConstraints(screenHeight: landscapeLength)
            
            readjustTextFieldConstraints(newHeight: minHeight)
            
            imagePickerView.frame.size.height = minHeight
        }
    }
    
    func readjustWidthConstraints(screenWidth: CGFloat)
    {
        // Adjusts the Image Picker View's Constraints to make the Image Picker View as thin as it can go
        
        imagePickerTrailingConstraint.constant = (screenWidth - minWidth) / 2
        imagePickerLeadingConstraint.constant = (screenWidth - minWidth) / 2
    }
    
    func readjustHeightConstraints(screenHeight: CGFloat)
    {
        // Adjusts the Image Picker View's Constraints to make the Image Picker View as short as it can go
        
        imagePickerBottomConstraint.constant = (screenHeight - totalHeightOfToolbars  - minHeight) / 2
        imagePickerTopConstraint.constant = imagePickerBottomConstraint.constant
    }
    
    func readjustTextFieldConstraints(newHeight: CGFloat)
    {
        // Adjusts the Text Field's constrants to fit into the shortest Image Picker's frame
        
        topTextFieldConstraintY.constant = defaultTextFieldConstantY + (getImagePickerHeight() - newHeight) / 2
        bottomTextFieldConstraintY.constant = topTextFieldConstraintY.constant
    }
    
    func hasProperWidth() -> Bool
    {
        // Determines if the Image Picker adjusted to the image's aspect ratio has a minimum width of 70
        
        let hasProperWidth: Bool
        let widthLength: CGFloat
        
        if isPortrait
        {
            widthLength = landscapeLength
        }
        else
        {
            widthLength = portraitLength
        }
        
        hasProperWidth = (widthLength - imagePickerLeadingConstraint.constant - imagePickerTrailingConstraint.constant) >= minWidth
        
        return hasProperWidth
    }
    
    func hasProperHeight() -> Bool
    {
        // Determines if the Image Picker adjusted to the image's aspect ratio has a minimum height of 120
        
        let hasProperHeight: Bool
        let heightLength: CGFloat
        
        if isPortrait
        {
            heightLength = portraitLength - totalHeightOfToolbars
        }
        else
        {
            heightLength = landscapeLength - totalHeightOfToolbars
        }
        
        hasProperHeight = (heightLength - imagePickerBottomConstraint.constant - imagePickerTopConstraint.constant) >= minHeight
        
        return hasProperHeight
    }
    
    func checkOutOfRangeVC(presentingVC: UIViewController, presentAlert: Bool)
    {
        // If the parent function specifies that an Alert must be presented, it presents an alert telling the user that the Image was either too thin or short and had to be readjusted.
        
        if presentAlert
        {
            // Presents an generic alert with an OK at the end
            
            // This is not an OK Alert because this View Controller also dimisses the presentingVC View Controller
            
            let imageOutOfRangeAlertController = UIAlertController()
            
            imageOutOfRangeAlertController.title =  "Image Out of Range"
            imageOutOfRangeAlertController.message = "Sorry, but Meme Me 1.0 does not support the selected image's dimensions in this orientation because the image is either too thin horizontally or too thin vertically.  The dimensions have been reset to allow the Meme Text Fields to fit."
            
            let okAction = UIAlertAction.init(title: "OK", style: UIAlertActionStyle.default)
            {
                action in self.dismiss(animated: true, completion: nil)
                
                presentingVC.dismiss(animated: true, completion: nil)
            }
            
            imageOutOfRangeAlertController.addAction(okAction)
            
            presentingVC.present(imageOutOfRangeAlertController, animated: true, completion: nil)
        }
    }
    
    func checkDismissal(picker: UIImagePickerController)
    {
        // Dismisses the Image Picker View Controller after the image's selection only if the image had a width more than minWidth and a height more than minHeight
        
        // This would not work if an Alert View Controller was also presented
        
        if hasProperRange
        {
            picker.dismiss(animated: true, completion: nil)
        }
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController)
    {
        picker.dismiss(animated: true, completion: nil)
    }
    
    
    // MARK: Share Button Functions
    
    @IBAction func shareButonPressed()
    {
        // Presents the Activity View Controller and generates a meme as the actvity item for it
        
        let activityController = UIActivityViewController.init(activityItems: [generateMemedImage()], applicationActivities: nil)
        
        self.present(activityController, animated: true, completion: nil)
        
        save()
    }
    
    
    func generateMemedImage() -> UIImage
    {
        actionToolbarsAreHidden(areHidden: true)
        
        let memedImage = drawImageFromView()
        
        let finalMemedImage = cropMemedImage(memedImage: memedImage)
        
        actionToolbarsAreHidden(areHidden: false)
        
        return finalMemedImage
    }
    
    func actionToolbarsAreHidden(areHidden: Bool)
    {
        // Hides or shows the toolbars based on the areHidden boolean parameter entered above
        
        memeActionsToolbar.isHidden = areHidden
        photoActionsToolbar.isHidden = areHidden
        
        adjustConstraints(areHidden: areHidden)
    }
    
    func adjustConstraints(areHidden: Bool)
    {
        // Adjusts constraints based on whether the toolbars are hidden or not
        
        // This prevents the skewing of the Image's height after the toolbars are hidden
        
        memeViewHeightConstraint.constant += areHidden ? -totalHeightOfToolbars : totalHeightOfToolbars
        topTextFieldConstraintY.constant += areHidden ? -(totalHeightOfToolbars / 2) : (totalHeightOfToolbars / 2)
        bottomTextFieldConstraintY.constant += areHidden ? -(totalHeightOfToolbars / 2) : (totalHeightOfToolbars / 2)
    }
    
    func drawImageFromView() -> UIImage
    {
        // Renders an image from the Meme View Controller (the entire screen)
        
        UIGraphicsBeginImageContext(self.view.frame.size)
        
        self.view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        
        let memedImage: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        
        UIGraphicsEndImageContext()
        
        return memedImage
    }
    
    func cropMemedImage(memedImage: UIImage) -> UIImage
    {
        // Crops the Image based on whether the device is portrait or landscape and whether the height or width was adjusted in the Image Picker View
        
        // Crops the generated image to look exactly how it was on the screen
        
        let finalMemedImage: UIImage
        let cropX, cropY, cropWidth, cropHeight: CGFloat
        
        
        cropX = imagePickerLeadingConstraint.constant
        cropY = 50 + imagePickerTopConstraint.constant
        
        if isPortrait
        {
            cropWidth = landscapeLength - imagePickerLeadingConstraint.constant * 2
            cropHeight = portraitLength + memeViewHeightConstraint.constant - imagePickerTopConstraint.constant * 2
        }
        else
        {
            cropWidth = portraitLength - imagePickerLeadingConstraint.constant * 2
            cropHeight = landscapeLength + memeViewHeightConstraint.constant - imagePickerTopConstraint.constant * 2
        }
        
        finalMemedImage = memedImage.crop(rect: CGRect(x: cropX, y: cropY, width: cropWidth, height: cropHeight))
        
        return finalMemedImage
    }
    
    func save()
    {
        // Creates a meme object
        
        // Honestly I have no idea what this is for, but I'm sure I'll figure as I progress in the lessons
        
        newMeme =  Meme(topText: topTextField.text, bottomText: bottomTextField.text, originalImage: imagePickerView.image, memeImage: generateMemedImage())
    }
    
    
    // MARK: Cancel Button Functions
    
    @IBAction func cancelButonPressed()
    {
        // Resets the Meme View Controller to its default state with no image and the text fields sayin "TOP" and "BOTTOM"
        
        // Also dismisses a keyboard if it's present
        
        imagePickerView.image = nil
        topTextField.text = "TOP"
        bottomTextField.text = "BOTTOM"
        
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
    
    

    
    // MARK: Text Field Delegate Functions
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool
    {
        // Determines if the top or bottom text field was touched and stores it in a boolean
        
        // The Top Text Field is tagged with a 0 and the Bottom Text Field is tagged with a 1
        
        if textField.tag == 0
        {
            topTextFieldTouched = true
        }
        else
        {
            topTextFieldTouched = false
        }
        
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        // Dismisses the keyboard
        
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        // Also dismisses the keyboard
        
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
        
        return true
    }
    
    
    // MARK: View Will Disappear Functions
    
    override func viewWillDisappear(_ animated: Bool)
    {
        // Unsubcribes from keyboard notifications
        
        super.viewWillDisappear(animated)
        
        unsubscribeFromKeyboardNotifications()
    }
    
    // MARK: Other Functions
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator)
    {
        // If there is an image in the Image Picker View, it adjusts the width/height of the Image Picker View to fit the aspect ratio of the image
        
        // That way the Image Picker View keeps its aspect ratio even when switching from portrait to landscape and vice versa
        
        // Also checks if the image is too thin or short and adjusts the Image Picker to the smallest size, this time with no alert presenting itself
        
        if let image = self.imagePickerView.image
        {
            adjustToProportionalImageSize(image: image)
            
            checkForProperImageRange(presentingVC: self, presentAlert: false)
            
            superDebug(mark: "VIEW WILL TRANSITION")
        }
    }
    
    func presentOKAlert(title: String, message: String)
    {
        let okAlertController = UIAlertController()
        
        okAlertController.title =  title
        okAlertController.message = message
        
        let okAction = UIAlertAction.init(title: "OK", style: UIAlertActionStyle.default)
        {
            action in self.dismiss(animated: true, completion: nil)
        }
        
        okAlertController.addAction(okAction)
        
        self.present(okAlertController, animated: true, completion: nil)
    }
    
    // MARK: Super Debugging Functions

    func superDebug(mark: String)
    {
        print("SUPER DEBUG: (MARK: \(mark)) \n")
        
        print("IS \(debugOrientation())\n")
        
        print("Portrait Length: \(portraitLength)")
        print("Landscape Length: \(landscapeLength)\n")
        
        print("Meme View Height Constraint: \(memeViewHeightConstraint.constant)\n")
        
        print("Image Picker Leading Constraint: \(imagePickerLeadingConstraint.constant)")
        print("Image Picker Trailing Constraint: \(imagePickerTrailingConstraint.constant)")
        print("Image Picker Top Constraint: \(imagePickerTopConstraint.constant)")
        print("Image Picker Bottom Constraint: \(imagePickerBottomConstraint.constant)\n")
        
        print("Top Text Field Y Constraint: \(topTextFieldConstraintY.constant)")
        print("Bottom Text Field Y Constraint: \(bottomTextFieldConstraintY.constant)\n")
        
        print("SUPER DEBUG END\n")
    }

    func debugOrientation() -> String
    {
        let orientation: String

        if isPortrait
        {
            orientation = "PORTRAIT"
        }
        else
        {
            orientation = "LANDSCAPE"
        }

        return orientation
    }
    
    func debug(message: String)
    {
        print(message)
    }
    
    
}

