//
//  UIImage Extension.swift
//  Meme3
//
//  Created by Kyle Humphrey on 8/3/17.
//  Copyright © 2017 Humphrey Corporations. All rights reserved.
//

import UIKit

extension UIImage {
    
    /*
     
        COMMENTS:
 
        Since it wasn't taught in the lessons, I did some research on the Internet and found a cropping method from 
     Stack Overflow.  The cropping method I used is not the same as the one I found, but it is based on it.  So I
     commented every area of the code to ensure that I understand it and I'm not just copying off of somebody.  The 
     crop method I found in Stack Overflow is below.
    
        Stack Overflow Link: https://stackoverflow.com/questions/39310729/problems-with-cropping-a-uiimage-in-swift
 
    */
    
    
    
    
    func crop( rect: CGRect) -> UIImage
    {
        // If the image is scaled 2x or 3x we can multiply the dimensions of the cropping rectangle to match the scale of the image.
        
        let imageScale = self.scale
        
        // We need to make rect a local variable because the rect in the parameter is a let constant and we need to be able to adjust the rectangle's x, y, width, and height, thus mutating rect
        
        var rect = rect
        
        // Here we do just that, mulitpling the scale number to each of the rectangle's dimensions
        
        rect.origin.x = rect.origin.x * imageScale
        rect.origin.y = rect.origin.y * imageScale
        rect.size.width = rect.size.width * imageScale
        rect.size.height = rect.size.height * imageScale
        
        // Here we actually use the CGImage's  cropping function with out rectangle to crop the image
        
        let imageReference = self.cgImage!.cropping(to: rect)
        
        // Since it came out originally as a CGImage, we need to make reconvert it back into a UIImage here
        
        let image = UIImage(cgImage: imageReference!, scale: imageScale, orientation: self.imageOrientation)
        
        // And we in conclusion, return the newly cropped UIImage!
        
        return image
    }
    
}
